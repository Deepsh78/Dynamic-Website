package model;


public class AboutusModel {

    private String companyName;

    private String companyDescription;

    private String phoneNumber;

    private String emailAddress;

    

	public String getCompanyName() {

		return companyName;

	}

	public void setCompanyName(String companyName) {

		this.companyName = companyName;

	}

	public String getCompanyDescription() {

		return companyDescription;

	}

	public void setCompanyDescription(String companyDescription) {

		this.companyDescription = companyDescription;

	}

	public String getPhoneNumber() {

		return phoneNumber;

	}

	public void setPhoneNumber(String phoneNumber) {

		this.phoneNumber = phoneNumber;

	}

	public String getEmailAddress() {

		return emailAddress;

	}

	public void setEmailAddress(String emailAddress) {

		this.emailAddress = emailAddress;

	}

	



    // getters and setters

}