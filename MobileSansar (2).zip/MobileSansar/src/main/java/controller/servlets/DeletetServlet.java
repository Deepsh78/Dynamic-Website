package controller.servlets; 
import java.io.IOException; import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest; 
import javax.servlet.http.HttpServletResponse; 
import controller.DatabaseController; /**
Servlet implementation class deleteProduct*/
import utils.StringUtils;
@WebServlet(asyncSupported = true, urlPatterns = { "/DeletetServlet" }) public class DeletetServlet extends HttpServlet { private static final long serialVersionUID = 1L;
DatabaseController dbController = new DatabaseController();
protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    String deleteId = request.getParameter("deleteId");

    if (deleteId != null && !deleteId.isEmpty()) {
        int deletedRows = dbController.deleteProductInfo(deleteId);
        if (deletedRows > 0) {
            request.setAttribute("successMessage", "Product deleted successfully.");
        } else {
            request.setAttribute("errorMessage", "Failed to delete product.");
        }
        // Forward to the same page after deletion
        request.getRequestDispatcher("/pages/MainAdmin.jsp").forward(request, response);
    }
}
}